import bpy
import os


class VIEW3D_PT_anim_io(bpy.types.Panel):
    bl_label = ".anim Tools"
    bl_idname = "VIEW3D_PT_anim_io"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "SW Toolkit"

    def draw(self, context):
        layout = self.layout
        obj = context.active_object

        outer_box = layout.box()

        # --- Import ---
        import_box = outer_box.box()
        import_box.label(text="Import", icon='IMPORT')
        import_box.operator("animio.import_anim", text="Import .anim", icon='FILE_FOLDER')

        # --- Export ---
        export_box = outer_box.box()
        export_box.label(text="Export", icon='EXPORT')

        if obj and obj.type == 'MESH' and obj.get("anim_source_path"):
            source = obj["anim_source_path"]
            export_box.label(text=f"Source: {os.path.basename(source)}", icon='FILE_TICK')
            export_box.operator("animio.export_anim", text="Export .anim", icon='FILE')
        elif obj and obj.type == 'MESH':
            export_box.label(text="No .anim source linked.", icon='ERROR')
            export_box.label(text="Import a file first.")
        else:
            export_box.label(text="Select an imported mesh.", icon='INFO')


# --------------------------
# Registration
# --------------------------
classes = (VIEW3D_PT_anim_io,)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
